﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace TinCount.ViewModels
{
    public partial class SignupViewModel : ObservableObject
    {
    }
}
